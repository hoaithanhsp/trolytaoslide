import { SlidePresentation } from './components/SlidePresentation';

function App() {
  return <SlidePresentation />;
}

export default App;
