export interface Slide {
  id: number;
  title: string;
  content: string;
}

// Empty default slides - hiển thị welcome screen
export const defaultSlides: Slide[] = [];
